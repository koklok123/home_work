#ну тут просто умнажаем + - / ну все в принципе
plus = lambda x, y: x + y
multiplication = lambda x, y: x * y 
minus = lambda x, y: x - y
dele = lambda x, y: x / y 