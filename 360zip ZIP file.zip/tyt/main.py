

from canculator import plus, multiplication, minus, dele
from palid import pal
from step import exponentiate

while True:
      
            choice = input("Выберите действие (арифметика, палиндром, степень, выход): ").strip().lower()
            print(f"Ваш выбор: {choice}")
            
            if choice == 'выход':
                print("Выход из программы")
                break
            elif choice == 'арифметика':
                operation = input("Выберите операцию (сложение, вычитание, умножение, деление): ").strip().lower()
                x = float(input("Введите первое число: "))
                y = float(input("Введите второе число: "))
                
                if operation == 'сложение':
                    print(f"Результат: {plus(x, y)}")
                elif operation == 'вычитание':
                    print(f"Результат: {minus(x, y)}")
                elif operation == 'деление':
                    print(f"Результат: {dele(x, y)}")
                elif operation == 'умножение':
                    print(f"Результат: {multiplication(x, y)}")
                else:
                    print("Неизвестная операция")
            elif choice == 'степень':
                base = int(input("Введите число для возведения в степень: "))
                exp = int(input("Введите степень: "))
                print(f"Результат: {exponentiate(base, exp)}")
           
            elif choice == 'палиндром':
                s = input("Введите строку: ")
                print(f"Это палиндром: {pal(s)}")
            else:
                print("Неизвестное действие")
